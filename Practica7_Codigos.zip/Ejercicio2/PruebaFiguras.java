public class PruebaFiguras {
    public static void main(String[] args) {
        Figura[] figuras = new Figura[3];
        figuras[0] = new Circulo("Rojo", 3);
        figuras[1] = new Rectangulo("Azul", 4, 6);
        figuras[2] = new Rectangulo("Verde", 5, 5);

        double areaTotal = 0;
        for (Figura f : figuras) {
            System.out.println(f);
            if (f instanceof Rectangulo) {
                Rectangulo r = (Rectangulo) f;
                System.out.println("  ¿Es cuadrado? "
                    + (r.esCuadrado() ? "Sí" : "No"));
            }
            double area = f.calcularArea();
            System.out.printf("  Área: %.2f  Perímetro: %.2f%n",
                area, f.calcularPerimetro());
            areaTotal += area;
        }
        System.out.printf("Área total: %.2f%n", areaTotal);
    }
}
