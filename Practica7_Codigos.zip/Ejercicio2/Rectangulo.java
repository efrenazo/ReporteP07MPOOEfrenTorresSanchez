public class Rectangulo extends Figura {
    private double base;
    private double altura;

    public Rectangulo(String color, double base,
            double altura) {
        super("Rectángulo", color);
        this.base = base;
        this.altura = altura;
    }

    public boolean esCuadrado() {
        return base == altura;
    }

    @Override
    public double calcularArea() {
        return base * altura;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * (base + altura);
    }

    @Override
    public String toString() {
        return super.toString()
            + " - " + base + " x " + altura;
    }
}
