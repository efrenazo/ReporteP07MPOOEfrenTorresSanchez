public class PruebaAnimal {
    public static void main(String[] args) {
        Animal[] animales = new Animal[2];
        animales[0] = new Animal("Nemo", 2, "Pez");
        animales[1] = new Perro("Firulais", 4, "Labrador");

        for (Animal a : animales) {
            System.out.println(a);
            System.out.println("  " + a.comer());
            System.out.println("  " + a.dormir());
            System.out.println("  " + a.hacerSonido());
            if (a instanceof Perro) {
                Perro p = (Perro) a;
                System.out.println("  " + p.traerPelota());
            }
        }
    }
}
