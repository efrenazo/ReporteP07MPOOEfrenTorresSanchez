public class Animal {
    protected String nombre;
    protected int edad;
    protected String especie;

    public Animal(String nombre, int edad, String especie) {
        this.nombre = nombre;
        this.edad = edad;
        this.especie = especie;
    }

    public String comer() {
        return nombre + " está comiendo.";
    }

    public String dormir() {
        return nombre + " está durmiendo.";
    }

    public String hacerSonido() {
        return nombre + " hace un sonido.";
    }

    @Override
    public String toString() {
        return nombre + " (" + especie + ", "
            + edad + " años)";
    }
}
