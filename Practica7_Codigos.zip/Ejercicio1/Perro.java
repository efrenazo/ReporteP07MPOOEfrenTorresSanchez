public class Perro extends Animal {
    private String raza;

    public Perro(String nombre, int edad, String raza) {
        super(nombre, edad, "Canino");
        this.raza = raza;
    }

    public String traerPelota() {
        return nombre + " trae la pelota.";
    }

    @Override
    public String hacerSonido() {
        return nombre + " dice: ¡Guau guau!";
    }

    @Override
    public String toString() {
        return "Perro: " + super.toString()
            + " - Raza: " + raza;
    }
}
