public class Gerente extends Empleado {
    private String departamento;
    private double bono;

    public Gerente(String numEmpleado, String nombre,
            double salarioBase, String departamento,
            double bono) {
        super(numEmpleado, nombre, salarioBase);
        this.departamento = departamento;
        this.bono = bono;
    }

    public String getDepartamento() {
        return departamento;
    }

    @Override
    public double calcularSalario() {
        return super.calcularSalario() + bono;
    }

    @Override
    public String presentarse() {
        return super.presentarse()
            + " Dirijo el área de " + departamento + ".";
    }

    @Override
    public String toString() {
        return "Gerente: " + super.toString();
    }
}
