public class Becario extends Empleado {
    private String universidad;
    private int horasSemana;

    public Becario(String numEmpleado, String nombre,
            double salarioBase, String universidad,
            int horasSemana) {
        super(numEmpleado, nombre, salarioBase);
        this.universidad = universidad;
        this.horasSemana = horasSemana;
    }

    @Override
    public double calcularSalario() {
        // apoyo proporcional a una jornada de 40 horas
        return super.calcularSalario() * horasSemana / 40.0;
    }

    @Override
    public String presentarse() {
        return super.presentarse()
            + " Soy becario de la " + universidad + ".";
    }

    @Override
    public String toString() {
        return "Becario: " + super.toString();
    }
}
