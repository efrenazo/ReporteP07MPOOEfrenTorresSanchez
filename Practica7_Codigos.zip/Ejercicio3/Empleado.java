public class Empleado {
    protected String numEmpleado;
    protected String nombre;
    protected double salarioBase;

    public Empleado(String numEmpleado, String nombre,
            double salarioBase) {
        this.numEmpleado = numEmpleado;
        this.nombre = nombre;
        this.salarioBase = salarioBase;
    }

    public double calcularSalario() {
        return salarioBase;
    }

    public String presentarse() {
        return "Hola, soy " + nombre
            + " y trabajo en la empresa.";
    }

    @Override
    public String toString() {
        return nombre + " (No. " + numEmpleado + ")";
    }
}
