public class PruebaEmpresa {
    public static void main(String[] args) {
        Empleado[] plantilla = new Empleado[4];
        plantilla[0] = new Gerente("G-001", "Laura Méndez",
            45000, "Tecnología", 12000);
        plantilla[1] = new Desarrollador("D-014", "Carlos Ruiz",
            30000, "Java", 10);
        plantilla[2] = new Desarrollador("D-021", "Ana Torres",
            32000, "Python", 4);
        plantilla[3] = new Becario("B-102", "Rafael Alejandro",
            12000, "UNAM", 20);

        double nomina = 0;
        for (Empleado e : plantilla) {
            System.out.println(e);
            System.out.println("  " + e.presentarse());
            if (e instanceof Gerente) {
                Gerente g = (Gerente) e;
                System.out.println("  -> Responsable del departamento "
                    + g.getDepartamento() + ".");
            }
            double salario = e.calcularSalario();
            System.out.println("  Salario mensual: $" + salario);
            nomina += salario;
        }
        System.out.println("Nómina total: $" + nomina);
    }
}
