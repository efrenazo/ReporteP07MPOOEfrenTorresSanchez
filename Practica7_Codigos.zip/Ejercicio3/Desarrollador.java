public class Desarrollador extends Empleado {
    private String lenguaje;
    private int horasExtra;

    public Desarrollador(String numEmpleado, String nombre,
            double salarioBase, String lenguaje,
            int horasExtra) {
        super(numEmpleado, nombre, salarioBase);
        this.lenguaje = lenguaje;
        this.horasExtra = horasExtra;
    }

    @Override
    public double calcularSalario() {
        double salario = super.calcularSalario();
        salario = salario + horasExtra * 250.0; // pago por hora extra
        return salario;
    }

    @Override
    public String presentarse() {
        return super.presentarse()
            + " Programo en " + lenguaje + ".";
    }

    @Override
    public String toString() {
        return "Desarrollador: " + super.toString();
    }
}
